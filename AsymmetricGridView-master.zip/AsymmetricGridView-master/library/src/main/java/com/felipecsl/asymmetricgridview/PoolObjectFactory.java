package com.felipecsl.asymmetricgridview;

public interface PoolObjectFactory<T> {
  T createObject();
}
